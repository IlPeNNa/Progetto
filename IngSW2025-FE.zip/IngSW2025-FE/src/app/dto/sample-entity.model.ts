
export class SampleEntity {
  id: string|undefined;
  name!: string;
}
