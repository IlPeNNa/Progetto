import {
  MatDivider,
  MatDividerModule
} from "./chunk-M2L66JDX.js";
import "./chunk-BKGN3QIE.js";
import "./chunk-DKBV3HU5.js";
import "./chunk-M3HR6BUY.js";
import "./chunk-H5HPXNXS.js";
import "./chunk-FC7CZYYG.js";
import "./chunk-VEE34BE5.js";
import "./chunk-WNVI4JOA.js";
import "./chunk-56PPHEMJ.js";
import "./chunk-S35MAB2V.js";
export {
  MatDivider,
  MatDividerModule
};
